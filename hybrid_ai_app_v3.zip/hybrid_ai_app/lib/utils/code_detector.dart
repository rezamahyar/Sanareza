class CodeBlock {
  final String language;
  final String filename;
  final String code;

  /// true when the filename was stated by the model (fence info or first-line comment).
  final bool named;
  CodeBlock({
    required this.language,
    required this.filename,
    required this.code,
    this.named = false,
  });
}

class CodeDetector {
  /// Fence with full info string: ```python lib/main.py
  static final fence = RegExp(r'```([^\n`]*)\n([\s\S]*?)```');
  static final _fileLike = RegExp(r'^[\w\-./\\]+\.[A-Za-z0-9]{1,8}$');
  static final _keyPrefix =
      RegExp(r'^(filename|file|title|path)=', caseSensitive: false);

  static CodeBlock fromMatch(RegExpMatch m) {
    final info = (m.group(1) ?? '').trim();
    final body = m.group(2) ?? '';
    final toks = info.split(RegExp(r'\s+')).where((t) => t.isNotEmpty).toList();
    var lang = toks.isNotEmpty ? toks.first : '';
    String? name;
    if (_fileLike.hasMatch(lang)) {
      name = lang;
      lang = lang.split('.').last;
    }
    if (name == null) {
      for (final t in toks.skip(1)) {
        final c = t.replaceFirst(_keyPrefix, '').replaceAll('"', '').replaceAll("'", '');
        if (_fileLike.hasMatch(c)) {
          name = c;
          break;
        }
      }
    }
    lang = lang.toLowerCase();
    name ??= _commentName(body);
    return CodeBlock(
      language: lang.isEmpty ? 'txt' : lang,
      filename: name ?? 'snippet_${DateTime.now().millisecondsSinceEpoch}.${extFor(lang)}',
      code: body,
      named: name != null,
    );
  }

  static List<CodeBlock> extract(String text) =>
      [for (final m in fence.allMatches(text)) fromMatch(m)];

  static String? _commentName(String body) {
    for (final line in body.split('\n').take(2)) {
      final m = RegExp(r'^\s*(?://|#|--|<!--)\s*(?:file(?:name)?:\s*)?([\w\-./]+\.[a-zA-Z0-9]+)')
          .firstMatch(line);
      if (m != null) return m.group(1);
    }
    return null;
  }

  static String extFor(String lang) {
    const map = {
      'python': 'py', 'py': 'py',
      'javascript': 'js', 'js': 'js', 'jsx': 'jsx',
      'typescript': 'ts', 'ts': 'ts', 'tsx': 'tsx',
      'dart': 'dart', 'html': 'html', 'css': 'css',
      'json': 'json', 'yaml': 'yaml', 'yml': 'yml',
      'java': 'java', 'kotlin': 'kt', 'swift': 'swift',
      'go': 'go', 'rust': 'rs', 'rs': 'rs', 'c': 'c',
      'cpp': 'cpp', 'c++': 'cpp', 'csharp': 'cs', 'cs': 'cs',
      'php': 'php', 'ruby': 'rb', 'rb': 'rb',
      'sql': 'sql', 'bash': 'sh', 'sh': 'sh', 'shell': 'sh',
    };
    return map[lang.toLowerCase()] ?? 'txt';
  }

  /// Maps language to a valid flutter_highlight theme key.
  static String safeHighlightLanguage(String lang) {
    const map = {
      'python': 'python', 'py': 'python',
      'javascript': 'javascript', 'js': 'javascript',
      'dart': 'dart', 'java': 'java', 'kotlin': 'kotlin',
      'swift': 'swift', 'go': 'go', 'rust': 'rust', 'rs': 'rust',
      'c': 'c', 'cpp': 'cpp', 'c++': 'cpp',
      'csharp': 'csharp', 'cs': 'csharp',
      'html': 'xml', 'xml': 'xml',
      'css': 'css', 'json': 'json', 'yaml': 'yaml', 'yml': 'yaml',
      'markdown': 'markdown', 'md': 'markdown',
      'bash': 'bash', 'sh': 'bash', 'shell': 'bash',
      'sql': 'sql', 'php': 'php', 'ruby': 'ruby', 'rb': 'ruby',
      'typescript': 'typescript', 'ts': 'typescript',
    };
    return map[lang.toLowerCase()] ?? 'plaintext';
  }
}
