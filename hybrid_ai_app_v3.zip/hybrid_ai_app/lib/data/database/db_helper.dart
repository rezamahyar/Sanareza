import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/chat_message.dart';
import '../models/conversation.dart';

class DbHelper {
  static final DbHelper _i = DbHelper._();
  factory DbHelper() => _i;
  DbHelper._();

  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'hybrid_ai.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (d, v) async {
        await d.execute('''
          CREATE TABLE conversations(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
          )
        ''');
        await d.execute('''
          CREATE TABLE messages(
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            attachments_json TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
          )
        ''');
        await d.execute(
            'CREATE INDEX idx_msg_conv ON messages(conversation_id, created_at)');
      },
    );
    return _db!;
  }

  Future<List<Conversation>> listConversations() async {
    final d = await db;
    final rows = await d.query('conversations', orderBy: 'updated_at DESC');
    return rows.map(Conversation.fromMap).toList();
  }

  Future<void> upsertConversation(Conversation c) async {
    final d = await db;
    await d.insert('conversations', c.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteConversation(String id) async {
    final d = await db;
    await d.delete('messages', where: 'conversation_id = ?', whereArgs: [id]);
    await d.delete('conversations', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ChatMessage>> listMessages(String convId) async {
    final d = await db;
    final rows = await d.query('messages',
        where: 'conversation_id = ?',
        whereArgs: [convId],
        orderBy: 'created_at ASC');
    return rows.map(ChatMessage.fromMap).toList();
  }

  Future<void> insertMessage(ChatMessage m) async {
    final d = await db;
    await d.insert('messages', m.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
