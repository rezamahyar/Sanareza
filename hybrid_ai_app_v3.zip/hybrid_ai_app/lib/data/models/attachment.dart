import '../../core/constants.dart';

class Attachment {
  final String id;
  final String name;
  final String path;
  final int sizeBytes;
  final AttachmentType type;
  final String? mimeType;
  String? extractedText;
  String? base64;
  List<String>? videoFrames;
  String? geminiDescription;

  Attachment({
    required this.id,
    required this.name,
    required this.path,
    required this.sizeBytes,
    required this.type,
    this.mimeType,
    this.extractedText,
    this.base64,
    this.videoFrames,
    this.geminiDescription,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'path': path,
        'sizeBytes': sizeBytes,
        'type': type.name,
        'mimeType': mimeType,
        'extractedText': extractedText,
        'geminiDescription': geminiDescription,
      };

  factory Attachment.fromJson(Map<String, dynamic> j) => Attachment(
        id: j['id'] as String,
        name: j['name'] as String,
        path: j['path'] as String,
        sizeBytes: j['sizeBytes'] as int,
        type: AttachmentType.values.firstWhere(
          (e) => e.name == j['type'],
          orElse: () => AttachmentType.unknown,
        ),
        mimeType: j['mimeType'] as String?,
        extractedText: j['extractedText'] as String?,
        geminiDescription: j['geminiDescription'] as String?,
      );
}
