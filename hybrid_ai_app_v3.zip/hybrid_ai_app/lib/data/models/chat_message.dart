import 'dart:convert';
import 'attachment.dart';

enum MessageRole { user, assistant, system }

class ChatMessage {
  final String id;
  final String conversationId;
  final MessageRole role;
  final String content;
  final List<Attachment> attachments;
  final DateTime createdAt;

  ChatMessage({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.attachments = const [],
    required this.createdAt,
  });

  ChatMessage copyWith({String? content, List<Attachment>? attachments}) =>
      ChatMessage(
        id: id,
        conversationId: conversationId,
        role: role,
        content: content ?? this.content,
        attachments: attachments ?? this.attachments,
        createdAt: createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'conversation_id': conversationId,
        'role': role.name,
        'content': content,
        'attachments_json':
            jsonEncode(attachments.map((a) => a.toJson()).toList()),
        'created_at': createdAt.millisecondsSinceEpoch,
      };

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id: m['id'] as String,
        conversationId: m['conversation_id'] as String,
        role: MessageRole.values.firstWhere(
          (e) => e.name == m['role'],
          orElse: () => MessageRole.user,
        ),
        content: m['content'] as String,
        attachments: (jsonDecode(m['attachments_json'] as String) as List)
            .map((e) => Attachment.fromJson(e as Map<String, dynamic>))
            .toList(),
        createdAt:
            DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
      );
}
