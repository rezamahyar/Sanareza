import 'package:shared_preferences/shared_preferences.dart';

/// Extra settings (model routing + code sandbox backend).
/// Kept separate from SettingsProvider so it works without touching it.
class ExtraSettings {
  static bool _loaded = false;
  static String routeMode = 'auto'; // auto | flash | pro
  static String sandbox = 'judge0'; // judge0 | piston
  static String judge0Url = 'https://ce.judge0.com';
  static String flashModel = 'deepseek-chat'; // cheap/fast model for simple questions
  static String pistonUrl = ''; // your own Piston instance, e.g. http://1.2.3.4:2000/api/v2

  static Future<void> load({bool force = false}) async {
    if (_loaded && !force) return;
    final p = await SharedPreferences.getInstance();
    routeMode = p.getString('x_route_mode') ?? routeMode;
    sandbox = p.getString('x_sandbox') ?? sandbox;
    judge0Url = p.getString('x_judge0_url') ?? judge0Url;
    pistonUrl = p.getString('x_piston_url') ?? pistonUrl;
    flashModel = p.getString('x_flash_model') ?? flashModel;
    _loaded = true;
  }

  static Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('x_route_mode', routeMode);
    await p.setString('x_sandbox', sandbox);
    await p.setString('x_judge0_url', judge0Url.trim());
    await p.setString('x_piston_url', pistonUrl.trim());
    await p.setString('x_flash_model', flashModel.trim());
  }
}
