class AppConstants {
  // ── Gemini ──────────────────────────────────────────
  static const String geminiBaseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';
  static const String defaultGeminiModel = 'gemini-2.0-flash';
  static const String geminiVisionPrompt =
      'You are a precise visual analyzer. Describe EVERYTHING in this image '
      'in exhaustive detail: all text (verbatim, including UI labels, code, '
      'buttons, tables), colors, layout, diagram structures, people, objects, '
      'and any semantic meaning. If it is a screenshot of code or UI, extract '
      'the code and structural hierarchy. Respond in the same language as the '
      'user request when applicable, otherwise in English.';

  // ── DeepSeek ─────────────────────────────────────────
  static const String deepseekBaseUrl =
      'https://api.deepseek.com/v1/chat/completions';
  static const String defaultDeepseekModel = 'deepseek-v4-pro';
  static const String deepseekSystemPrompt =
      'You are an elite senior software architect and reasoning engine. '
      'Answer in the user\'s language (Persian if they wrote Persian). '
      'When you generate code, ALWAYS wrap each file in a fenced code block '
      'with the correct language tag (e.g. ```python filename.py). '
      'Be rigorous, complete, and never truncate working code. '
      'Always give every file as its own fenced block whose info string is '
      '"language path/filename.ext" so the app can zip them exactly. '
      'Keep non-code prose concise; for small edits return only the changed '
      'files; answer simple questions in a few sentences.';

  // ── Piston Code Sandbox ─────────────────────────────
  static const String pistonBaseUrl = 'https://emkc.org/api/v2/piston';

  // ── Off-Peak (DeepSeek 50% discount) ─────────────────
  static const int offPeakStartUtcMinutes = 16 * 60 + 30;
  static const int offPeakEndUtcMinutes = 0;

  // ── Processing limits ────────────────────────────────
  static const int maxVideoFrames = 8;
  static const int maxZipTextBytes = 200 * 1024;
  static const int maxTotalExtractBytes = 600 * 1024;
  static const int maxChatHistoryMessages = 20;

  // ── SharedPreferences keys ───────────────────────────
  static const String kGeminiKey = 'gemini_api_key';
  static const String kDeepseekKey = 'deepseek_api_key';
  static const String kGeminiModel = 'gemini_model';
  static const String kDeepseekModel = 'deepseek_model';
  static const String kThemeMode = 'theme_mode';
}

enum AttachmentType { image, video, document, archive, code, unknown }
