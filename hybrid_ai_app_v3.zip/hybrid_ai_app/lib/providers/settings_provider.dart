import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants.dart';

class SettingsProvider extends ChangeNotifier {
  late SharedPreferences _prefs;

  String _geminiKey = '';
  String _deepseekKey = '';
  String _geminiModel = AppConstants.defaultGeminiModel;
  String _deepseekModel = AppConstants.defaultDeepseekModel;
  ThemeMode _themeMode = ThemeMode.system;

  String get geminiKey => _geminiKey;
  String get deepseekKey => _deepseekKey;
  String get geminiModel => _geminiModel;
  String get deepseekModel => _deepseekModel;
  ThemeMode get themeMode => _themeMode;
  bool get ready => _geminiKey.isNotEmpty && _deepseekKey.isNotEmpty;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _geminiKey = _prefs.getString(AppConstants.kGeminiKey) ?? '';
    _deepseekKey = _prefs.getString(AppConstants.kDeepseekKey) ?? '';
    _geminiModel = _prefs.getString(AppConstants.kGeminiModel) ??
        AppConstants.defaultGeminiModel;
    _deepseekModel = _prefs.getString(AppConstants.kDeepseekModel) ??
        AppConstants.defaultDeepseekModel;
    final tm = _prefs.getString(AppConstants.kThemeMode) ?? 'system';
    _themeMode = switch (tm) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    notifyListeners();
  }

  Future<void> setGeminiKey(String v) async {
    _geminiKey = v.trim();
    await _prefs.setString(AppConstants.kGeminiKey, _geminiKey);
    notifyListeners();
  }

  Future<void> setDeepseekKey(String v) async {
    _deepseekKey = v.trim();
    await _prefs.setString(AppConstants.kDeepseekKey, _deepseekKey);
    notifyListeners();
  }

  Future<void> setGeminiModel(String v) async {
    _geminiModel = v.trim();
    await _prefs.setString(AppConstants.kGeminiModel, _geminiModel);
    notifyListeners();
  }

  Future<void> setDeepseekModel(String v) async {
    _deepseekModel = v.trim();
    await _prefs.setString(AppConstants.kDeepseekModel, _deepseekModel);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode m) async {
    _themeMode = m;
    await _prefs.setString(AppConstants.kThemeMode, m.name);
    notifyListeners();
  }
}
