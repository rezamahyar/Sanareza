import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../data/database/db_helper.dart';
import '../data/models/attachment.dart';
import '../data/models/chat_message.dart';
import '../data/models/conversation.dart';
import '../services/deepseek_service.dart';
import '../services/file_processor.dart';
import '../services/gemini_service.dart';
import '../services/token_service.dart';
import '../services/video_processor.dart';
import 'settings_provider.dart';
import '../core/extra_settings.dart';
import '../services/token_tuner.dart';

class ChatProvider extends ChangeNotifier {
  final DbHelper _db = DbHelper();
  final SettingsProvider settings;

  ChatProvider(this.settings);

  Conversation? _activeConversation;
  List<ChatMessage> _messages = [];
  bool _sending = false;
  String? _error;
  int _tokensUsed = 0;

  Conversation? get activeConversation => _activeConversation;
  List<ChatMessage> get messages => List.unmodifiable(_messages);
  bool get sending => _sending;
  String? get error => _error;
  int get tokensUsed => _tokensUsed;
  double get costMultiplier => TokenService.costMultiplier();

  Future<void> newConversation() async {
    final now = DateTime.now();
    final c = Conversation(
      id: now.microsecondsSinceEpoch.toString(),
      title: 'گفتگوی جدید',
      createdAt: now,
      updatedAt: now,
    );
    await _db.upsertConversation(c);
    _activeConversation = c;
    _messages = [];
    _error = null;
    notifyListeners();
  }

  Future<void> openConversation(Conversation c) async {
    _activeConversation = c;
    _messages = await _db.listMessages(c.id);
    _error = null;
    notifyListeners();
  }

  Future<void> deleteConversation(String id) async {
    await _db.deleteConversation(id);
    if (_activeConversation?.id == id) {
      _activeConversation = null;
      _messages = [];
    }
    notifyListeners();
  }

  Future<List<Conversation>> listConversations() => _db.listConversations();

  Future<void> send({
    required String userText,
    required List<Attachment> attachments,
  }) async {
    if (_sending) return;
    if (_activeConversation == null) await newConversation();

    if (!settings.ready) {
      _error = 'لطفاً ابتدا کلیدهای Gemini و DeepSeek را در تنظیمات وارد کنید.';
      notifyListeners();
      return;
    }

    _sending = true;
    _error = null;
    notifyListeners();

    try {
      final parts = <String>[];
      if (userText.trim().isNotEmpty) parts.add(userText.trim());

      for (final a in attachments) {
        parts.add('=== ATTACHMENT: ${a.name} ===');
        switch (a.type) {
          case AttachmentType.image:
            final bytes = await File(a.path).readAsBytes();
            a.base64 = base64Encode(bytes);
            final desc = await GeminiService(
              apiKey: settings.geminiKey,
              model: settings.geminiModel,
            ).describeImageBase64(a.base64!);
            a.geminiDescription = desc;
            parts.add('[Gemini image description]\n$desc');
            break;

          case AttachmentType.video:
            final key = await VideoProcessor.extractKeyframes(a.path);
            a.videoFrames = key.frames;
            final desc = await GeminiService(
              apiKey: settings.geminiKey,
              model: settings.geminiModel,
            ).describeVideoFrames(key.frames, key.timestamps);
            a.geminiDescription = desc;
            parts.add('[Gemini video timeline description]\n$desc');
            break;

          case AttachmentType.document:
          case AttachmentType.archive:
          case AttachmentType.code:
            final text = await FileProcessor.extractText(a.path, a.type);
            a.extractedText = text;
            parts.add('[Extracted content]\n${text ?? "«بدون متن»"}');
            break;

          case AttachmentType.unknown:
            parts.add('[Unsupported file]');
            break;
        }
      }

      final enriched = parts.join('\n\n');

      final userMsg = ChatMessage(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        conversationId: _activeConversation!.id,
        role: MessageRole.user,
        content: userText.trim(),
        attachments: attachments,
        createdAt: DateTime.now(),
      );
      await _db.insertMessage(userMsg);
      _messages.add(userMsg);
      _tokensUsed += TokenService.estimate(enriched);
      notifyListeners();

      final history = <Map<String, dynamic>>[];
      final recent = _messages.length > Tuning.maxHistory
          ? _messages
              .sublist(_messages.length - Tuning.maxHistory)
          : _messages;

      for (final m in recent) {
        if (m.role == MessageRole.system) continue;
        final content =
            (m.id == userMsg.id) ? enriched : m.content;
        history.add({
          'role': m.role == MessageRole.user ? 'user' : 'assistant',
          'content': content,
        });
      }

      final assistantMsg = ChatMessage(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        conversationId: _activeConversation!.id,
        role: MessageRole.assistant,
        content: '',
        createdAt: DateTime.now(),
      );
      _messages.add(assistantMsg);
      notifyListeners();

      await ExtraSettings.load();
      TokenTuner.compactInPlace(history);
      final chosenModel = ModelRouter.pick(
        mode: ExtraSettings.routeMode,
        text: userText,
        hasAttachments: attachments.isNotEmpty,
        flash: ExtraSettings.flashModel,
        pro: settings.deepseekModel,
      );
      final service = DeepseekService(
        apiKey: settings.deepseekKey,
        model: chosenModel,
      );

      final buffer = StringBuffer();
      await for (final chunk in service.streamChat(messages: history)) {
        buffer.write(chunk);
        final idx = _messages.indexWhere((m) => m.id == assistantMsg.id);
        _messages[idx] =
            _messages[idx].copyWith(content: buffer.toString());
        notifyListeners();
      }

      final finalMsg =
          _messages.firstWhere((m) => m.id == assistantMsg.id);
      await _db.insertMessage(finalMsg);
      _tokensUsed += TokenService.estimate(finalMsg.content);

      if (_messages.length == 2) {
        final title = userText.trim().isEmpty
            ? 'گفتگو با فایل'
            : (userText.length > 40
                ? '${userText.substring(0, 40)}…'
                : userText);
        _activeConversation = _activeConversation!
            .copyWith(title: title, updatedAt: DateTime.now());
        await _db.upsertConversation(_activeConversation!);
      } else {
        _activeConversation = _activeConversation!
            .copyWith(updatedAt: DateTime.now());
        await _db.upsertConversation(_activeConversation!);
      }
    } catch (e) {
      _error = _friendlyError(e);
    } finally {
      _sending = false;
      notifyListeners();
    }
  }

  String _friendlyError(Object e) {
    final s = e.toString().toLowerCase();
    if (s.contains('socket') ||
        s.contains('network') ||
        s.contains('connection') ||
        s.contains('timeout')) {
      return 'خطای شبکه: اتصال اینترنت را بررسی کنید.';
    }
    if (s.contains('401') ||
        s.contains('unauthorized') ||
        s.contains('invalid api key')) {
      return 'کلید API نامعتبر است. آن را در تنظیمات بررسی کنید.';
    }
    if (s.contains('429') || s.contains('quota')) {
      return 'سهمیه (quota) یکی از کلیدها تمام شده است.';
    }
    if (s.contains('model not found') || s.contains('404')) {
      return 'نام مدل یافت نشد. در تنظیمات نام مدل را بررسی کنید.';
    }
    return 'خطا: $e';
  }
}
