/// Token-saving helpers: cheap-model routing + history compaction.
class Tuning {
  /// Max prior messages re-sent to the model (was 20).
  static const int maxHistory = 8;
  static const int oldUserCap = 1500;
  static const int oldAssistantCap = 3000;
  static const int codeKeepLines = 12;
  static const int codeCompactAbove = 40;
}

class ModelRouter {
  static const List<String> _heavy = [
    'کد', 'برنامه', 'بنویس', 'بساز', 'ساخت', 'پروژه', 'باگ', 'خطا', 'اصلاح',
    'تحلیل', 'زیپ', 'فایل', 'اپلیکیشن', 'الگوریتم', 'طراحی', 'مقایسه', 'بهینه',
    'code', 'build', 'create', 'write', 'fix', 'bug', 'error', 'debug',
    'refactor', 'implement', 'zip', 'file', 'project', 'analy', 'design',
    'compare', 'optimi', 'script', 'function', 'class ',
  ];

  static bool isSimple(String text, bool hasAttachments) {
    if (hasAttachments) return false;
    final t = text.trim();
    if (t.isEmpty || t.length > 220) return false;
    if (t.contains('```') || '\n'.allMatches(t).length > 2) return false;
    final l = t.toLowerCase();
    for (final k in _heavy) {
      if (l.contains(k)) return false;
    }
    return true;
  }

  /// mode: auto | flash | pro
  static String pick({
    required String mode,
    required String text,
    required bool hasAttachments,
    required String flash,
    required String pro,
  }) {
    if (flash.trim().isEmpty) return pro;
    if (mode == 'pro') return pro;
    if (mode == 'flash') return flash;
    return isSimple(text, hasAttachments) ? flash : pro;
  }
}

class TokenTuner {
  static final RegExp _fence = RegExp(r'```([^\n`]*)\n([\s\S]*?)```');

  /// Compacts OLD turns in place. Keeps the latest assistant message and the
  /// current (last) user message untouched so "fix that code" still works.
  static void compactInPlace(List<Map<String, dynamic>> h) {
    var lastAsst = -1;
    for (var i = h.length - 1; i >= 0; i--) {
      if (h[i]['role'] == 'assistant') {
        lastAsst = i;
        break;
      }
    }
    for (var i = 0; i < h.length - 1; i++) {
      if (i == lastAsst) continue;
      final c = h[i]['content'];
      if (c is! String) continue;
      h[i]['content'] = h[i]['role'] == 'assistant'
          ? _cap(_compactCode(c), Tuning.oldAssistantCap)
          : _cap(c, Tuning.oldUserCap);
    }
  }

  static String _cap(String s, int n) =>
      s.length <= n ? s : '${s.substring(0, n)}\n[…truncated to save tokens]';

  static String _compactCode(String s) => s.replaceAllMapped(_fence, (m) {
        final lines = (m.group(2) ?? '').split('\n');
        if (lines.length <= Tuning.codeCompactAbove) return m.group(0)!;
        final head = lines.take(Tuning.codeKeepLines).join('\n');
        return '```${m.group(1)}\n$head\n// … ${lines.length - Tuning.codeKeepLines} lines omitted (old turn) …\n```';
      });
}
