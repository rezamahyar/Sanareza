import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:video_thumbnail/video_thumbnail.dart';
import '../core/constants.dart';

class VideoProcessor {
  static Future<({List<String> frames, List<double> timestamps})>
      extractKeyframes(String videoPath) async {
    final count = AppConstants.maxVideoFrames;
    final file = File(videoPath);
    final sizeMb = (await file.length()) / (1024 * 1024);
    final approxDurationMs = (sizeMb * 1000).clamp(3000, 300000).toInt();

    final frames = <String>[];
    final timestamps = <double>[];

    for (var i = 0; i < count; i++) {
      final timeMs = (approxDurationMs * (i + 1) / (count + 1)).toInt();
      final Uint8List? thumb = await VideoThumbnail.thumbnailData(
        video: videoPath,
        imageFormat: ImageFormat.JPEG,
        timeMs: timeMs,
        quality: 70,
        maxWidth: 720,
      );
      if (thumb == null) continue;
      frames.add(base64Encode(thumb));
      timestamps.add(timeMs / 1000.0);
    }
    return (frames: frames, timestamps: timestamps);
  }
}
