import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/constants.dart';

class DeepseekService {
  final String apiKey;
  final String model;
  DeepseekService({required this.apiKey, required this.model});

  Stream<String> streamChat({
    required List<Map<String, dynamic>> messages,
  }) async* {
    if (apiKey.isEmpty) {
      throw Exception('DeepSeek API key is empty. Please set it in Settings.');
    }

    final full = [
      {'role': 'system', 'content': AppConstants.deepseekSystemPrompt},
      ...messages,
    ];

    final request =
        http.Request('POST', Uri.parse(AppConstants.deepseekBaseUrl));
    request.headers['Content-Type'] = 'application/json';
    request.headers['Authorization'] = 'Bearer $apiKey';
    request.body = jsonEncode({
      'model': model,
      'messages': full,
      'stream': true,
      'temperature': 0.6,
    });

    final client = http.Client();
    try {
      final res = await client.send(request);
      if (res.statusCode != 200) {
        final body = await res.stream.bytesToString();
        throw Exception('DeepSeek error ${res.statusCode}: $body');
      }

      String buffer = '';
      await for (final chunk in res.stream.transform(utf8.decoder)) {
        buffer += chunk;
        final lines = buffer.split('\n');
        buffer = lines.removeLast();
        for (final line in lines) {
          final trimmed = line.trim();
          if (trimmed.isEmpty) continue;
          if (!trimmed.startsWith('data:')) continue;
          final payload = trimmed.substring(5).trim();
          if (payload == '[DONE]') return;
          try {
            final j = jsonDecode(payload) as Map<String, dynamic>;
            final delta =
                j['choices']?[0]?['delta']?['content'] as String?;
            if (delta != null && delta.isNotEmpty) yield delta;
          } catch (_) {}
        }
      }
    } finally {
      client.close();
    }
  }
}
