import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/code_detector.dart';

/// Builds an exact ZIP from the fenced code blocks of an assistant message.
/// Blocks that carry a filename (```python src/app.py) keep their path; a later
/// block with the same path replaces the earlier one (model revised the file).
class ZipBuilder {
  static const _skipLangs = {'text', 'txt', 'console', 'output', 'log', 'diff'};

  static String _safe(String n) => n
      .replaceAll('\\', '/')
      .split('/')
      .where((p) => p.isNotEmpty && p != '.' && p != '..')
      .join('/');

  static List<CodeBlock> _zippable(String text) => [
        for (final b in CodeDetector.extract(text))
          if (b.named || !_skipLangs.contains(b.language)) b
      ];

  static int count(String text) =>
      text.contains('```') ? _zippable(text).length : 0;

  static Future<File?> build(String text, {String name = 'project'}) async {
    final blocks = _zippable(text);
    if (blocks.isEmpty) return null;
    final files = <String, List<int>>{};
    var n = 0;
    for (final b in blocks) {
      var fn = b.named ? _safe(b.filename) : '';
      if (fn.isEmpty) {
        n++;
        fn = 'snippet_$n.${CodeDetector.extFor(b.language)}';
      }
      final code = b.code.endsWith('\n') ? b.code : '${b.code}\n';
      files[fn] = utf8.encode(code);
    }
    final ar = Archive();
    files.forEach((k, v) => ar.addFile(ArchiveFile(k, v.length, v)));
    final data = ZipEncoder().encode(ar);
    if (data == null) return null;
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/${name}_${DateTime.now().millisecondsSinceEpoch}.zip');
    await f.writeAsBytes(data);
    return f;
  }

  static Future<int> buildAndShare(String text) async {
    final f = await build(text);
    if (f == null) return 0;
    await Share.shareXFiles([XFile(f.path)]);
    return count(text);
  }
}
