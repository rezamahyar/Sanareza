import '../core/constants.dart';

class TokenService {
  static int estimate(String text) {
    if (text.isEmpty) return 0;
    return (text.length / 3).ceil();
  }

  static bool isOffPeak([DateTime? when]) {
    final now = (when ?? DateTime.now()).toUtc();
    final minutes = now.hour * 60 + now.minute;
    final start = AppConstants.offPeakStartUtcMinutes;
    final end = AppConstants.offPeakEndUtcMinutes;
    if (start > end) return minutes >= start || minutes < end;
    return minutes >= start && minutes < end;
  }

  static double costMultiplier() => isOffPeak() ? 0.5 : 1.0;
}
