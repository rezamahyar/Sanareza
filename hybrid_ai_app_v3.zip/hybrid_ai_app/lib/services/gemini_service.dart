import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/constants.dart';

class GeminiService {
  final String apiKey;
  final String model;
  GeminiService({required this.apiKey, required this.model});

  Future<String> _call(Map<String, dynamic> body) async {
    if (apiKey.isEmpty) {
      throw Exception('Gemini API key is empty. Please set it in Settings.');
    }
    final uri = Uri.parse(
        '${AppConstants.geminiBaseUrl}/$model:generateContent?key=$apiKey');
    final res = await http
        .post(uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body))
        .timeout(const Duration(seconds: 60));

    if (res.statusCode != 200) {
      throw Exception('Gemini error ${res.statusCode}: ${res.body}');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List?;
    if (candidates == null || candidates.isEmpty) {
      throw Exception('Gemini returned no candidates.');
    }
    final parts =
        (candidates.first['content']?['parts'] as List?) ?? const [];
    final buffer = StringBuffer();
    for (final p in parts) {
      if (p['text'] != null) buffer.write(p['text']);
    }
    return buffer.toString().trim();
  }

  Future<String> describeImageBase64(String base64Image) {
    return _call({
      'contents': [
        {
          'parts': [
            {'text': AppConstants.geminiVisionPrompt},
            {
              'inline_data': {
                'mime_type': 'image/jpeg',
                'data': base64Image,
              }
            }
          ]
        }
      ],
      'generationConfig': {'temperature': 0.2, 'maxOutputTokens': 2048},
    });
  }

  Future<String> describeVideoFrames(
      List<String> frameBase64s, List<double> timestampsSec) async {
    final buffer = StringBuffer();
    for (var i = 0; i < frameBase64s.length; i++) {
      final ts = timestampsSec[i].toStringAsFixed(1);
      final desc = await describeImageBase64(frameBase64s[i]);
      buffer.writeln('--- Frame @ ${ts}s ---');
      buffer.writeln(desc);
      buffer.writeln();
    }
    return buffer.toString().trim();
  }
}
