import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/extra_settings.dart';

class CodeTestResult {
  final String stdout;
  final String stderr;
  final String compileStderr;
  final int exitCode;
  final int compileExitCode;
  final Duration elapsed;

  CodeTestResult({
    required this.stdout,
    required this.stderr,
    required this.compileStderr,
    required this.exitCode,
    required this.compileExitCode,
    required this.elapsed,
  });

  bool get success => exitCode == 0 && compileExitCode == 0;
}

/// Code sandbox. The public Piston API (emkc.org) became whitelist-only on
/// 2026-02-15 (HTTP 401), so the default backend is now Judge0 CE; a
/// self-hosted Piston URL can be configured in Settings → Tools.
class CodeTestService {
  static Map<String, String>? _runtimesCache;
  static String? _runtimesCacheUrl;

  static const Map<String, String> _langMap = {
    'python': 'python', 'py': 'python',
    'javascript': 'javascript', 'js': 'javascript',
    'typescript': 'typescript', 'ts': 'typescript',
    'dart': 'dart',
    'java': 'java',
    'kotlin': 'kotlin',
    'swift': 'swift',
    'go': 'go',
    'rust': 'rust', 'rs': 'rust',
    'c': 'c',
    'cpp': 'c++', 'c++': 'c++',
    'csharp': 'csharp', 'cs': 'csharp', 'c#': 'csharp',
    'php': 'php',
    'ruby': 'ruby', 'rb': 'ruby',
    'bash': 'bash', 'sh': 'bash', 'shell': 'bash',
  };

  // Judge0 CE language ids (Dart is not available there).
  static const Map<String, int> _judge0Ids = {
    'python': 71, 'javascript': 63, 'typescript': 74, 'java': 62,
    'kotlin': 78, 'swift': 83, 'go': 60, 'rust': 73, 'c': 50, 'c++': 54,
    'csharp': 51, 'php': 68, 'ruby': 72, 'bash': 46,
  };

  static bool isWebLanguage(String lang) {
    final l = lang.toLowerCase();
    return l == 'html' || l == 'htm' || l == 'xml' || l == 'css';
  }

  static bool isExecutable(String lang) =>
      _langMap.containsKey(lang.toLowerCase());

  static Future<CodeTestResult> run({
    required String code,
    required String language,
    String stdin = '',
  }) async {
    await ExtraSettings.load();
    final lang = _langMap[language.toLowerCase()];
    if (lang == null) {
      throw Exception(
          'زبان «$language» توسط سندباکس پشتیبانی نمی‌شود. برای HTML/CSS از پیش‌نمایش استفاده کنید.');
    }
    if (ExtraSettings.sandbox == 'piston') {
      if (ExtraSettings.pistonUrl.trim().isEmpty) {
        throw Exception(
            'آدرس Piston شخصی در تنظیمات → ابزارها خالی است (Piston عمومی از ۲۰۲۶/۰۲/۱۵ بسته شده).');
      }
      return _runPiston(lang, code, stdin);
    }
    return _runJudge0(lang, code, stdin);
  }

  // ---------------- Judge0 ----------------
  static Future<CodeTestResult> _runJudge0(
      String lang, String code, String stdin) async {
    final id = _judge0Ids[lang];
    if (id == null) {
      throw Exception(
          'زبان «$lang» در Judge0 عمومی نیست. در تنظیمات → ابزارها Piston شخصی وصل کنید.');
    }
    final base = ExtraSettings.judge0Url.trim().replaceAll(RegExp(r'/+$'), '');
    final sw = Stopwatch()..start();
    final res = await http
        .post(
          Uri.parse('$base/submissions?base64_encoded=false&wait=true'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'source_code': code,
            'language_id': id,
            'stdin': stdin,
          }),
        )
        .timeout(const Duration(seconds: 60));
    sw.stop();
    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('خطای سندباکس ${res.statusCode}: $body');
    }
    final j = jsonDecode(body) as Map<String, dynamic>;
    final statusId = (j['status']?['id'] as int?) ?? 0;
    final statusDesc = (j['status']?['description'] as String?) ?? '';
    final compile = (j['compile_output'] as String?) ?? '';
    var stderr = (j['stderr'] as String?) ?? '';
    final msg = (j['message'] as String?) ?? '';
    if (msg.isNotEmpty) stderr = '$stderr\n$msg'.trim();
    final compileFailed = statusId == 6;
    var exit = 0;
    if (!compileFailed && statusId != 3) {
      exit = (j['exit_code'] as int?) ?? 1;
      if (exit == 0) exit = 1;
      if (stderr.isEmpty) stderr = statusDesc;
    }
    return CodeTestResult(
      stdout: (j['stdout'] as String?) ?? '',
      stderr: stderr,
      compileStderr: compile,
      exitCode: exit,
      compileExitCode: compileFailed ? 1 : 0,
      elapsed: sw.elapsed,
    );
  }

  // ---------------- Piston (self-hosted) ----------------
  static String get _pistonBase =>
      ExtraSettings.pistonUrl.trim().replaceAll(RegExp(r'/+$'), '');

  static Future<CodeTestResult> _runPiston(
      String lang, String code, String stdin) async {
    final version = await _resolvePistonVersion(lang);
    final sw = Stopwatch()..start();
    final response = await http
        .post(
          Uri.parse('$_pistonBase/execute'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'language': lang,
            'version': version,
            'files': [
              {'content': code}
            ],
            'stdin': stdin,
          }),
        )
        .timeout(const Duration(seconds: 45));
    sw.stop();
    if (response.statusCode != 200) {
      throw Exception('خطای سندباکس ${response.statusCode}: ${response.body}');
    }
    final j = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final runObj = (j['run'] as Map?) ?? {};
    final compileObj = (j['compile'] as Map?) ?? {};
    return CodeTestResult(
      stdout: (runObj['stdout'] as String?) ?? '',
      stderr: (runObj['stderr'] as String?) ?? '',
      compileStderr: (compileObj['stderr'] as String?) ?? '',
      exitCode: (runObj['code'] as int?) ?? 0,
      compileExitCode: (compileObj['code'] as int?) ?? 0,
      elapsed: sw.elapsed,
    );
  }

  static Future<String> _resolvePistonVersion(String lang) async {
    if (_runtimesCache == null || _runtimesCacheUrl != _pistonBase) {
      final res = await http
          .get(Uri.parse('$_pistonBase/runtimes'))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        throw Exception('لیست زبان‌های Piston دریافت نشد (${res.statusCode}).');
      }
      final map = <String, String>{};
      for (final r in jsonDecode(res.body) as List) {
        map[r['language'] as String] = r['version'] as String;
      }
      _runtimesCache = map;
      _runtimesCacheUrl = _pistonBase;
    }
    final v = _runtimesCache![lang];
    if (v == null) throw Exception('زبان «$lang» روی این Piston نصب نیست.');
    return v;
  }
}
