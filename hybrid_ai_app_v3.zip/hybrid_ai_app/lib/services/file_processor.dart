import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:xml/xml.dart';
import 'package:path/path.dart' as p;
import '../core/constants.dart';
import '../data/models/attachment.dart';

class FileProcessor {
  static final Set<String> _codeExt = {
    'dart', 'py', 'js', 'ts', 'jsx', 'tsx', 'html', 'css', 'scss',
    'json', 'yaml', 'yml', 'md', 'txt', 'c', 'cpp', 'h', 'hpp',
    'java', 'kt', 'swift', 'go', 'rs', 'sh', 'xml', 'sql', 'php',
    'rb', 'cs', 'gradle', 'toml', 'ini', 'env', 'gitignore', 'properties'
  };

  static AttachmentType classify(String path) {
    final ext = p.extension(path).toLowerCase().replaceFirst('.', '');
    if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'].contains(ext)) {
      return AttachmentType.image;
    }
    if (['mp4', 'mov', 'mkv', 'avi', 'webm', 'm4v'].contains(ext)) {
      return AttachmentType.video;
    }
    if (['zip', 'tar', 'gz'].contains(ext)) {
      return AttachmentType.archive;
    }
    if (['pdf', 'docx', 'doc'].contains(ext)) {
      return AttachmentType.document;
    }
    if (_codeExt.contains(ext)) return AttachmentType.code;
    return AttachmentType.unknown;
  }

  static Future<String?> extractText(String path, AttachmentType type) async {
    try {
      switch (type) {
        case AttachmentType.document:
          return await _extractDocument(path);
        case AttachmentType.archive:
          return await _extractArchive(path);
        case AttachmentType.code:
          return await _readPlain(path);
        default:
          return null;
      }
    } catch (e) {
      return '[Error extracting $path: $e]';
    }
  }

  static Future<String?> _readPlain(String path) async {
    final bytes = await File(path).readAsBytes();
    final take = bytes.length > AppConstants.maxZipTextBytes
        ? bytes.sublist(0, AppConstants.maxZipTextBytes)
        : bytes;
    return utf8.decode(take, allowMalformed: true);
  }

  static Future<String?> _extractDocument(String path) async {
    final ext = p.extension(path).toLowerCase();
    if (ext == '.pdf') {
      final bytes = await File(path).readAsBytes();
      final doc = PdfDocument(inputBytes: bytes);
      final text = PdfTextExtractor(doc).extractText();
      doc.dispose();
      return text;
    }
    if (ext == '.docx') {
      final bytes = await File(path).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final entry = archive.files.firstWhere(
        (f) => f.name == 'word/document.xml',
        orElse: () => throw Exception('document.xml not found'),
      );
      final xmlStr = utf8.decode(entry.content as List<int>);
      final doc = XmlDocument.parse(xmlStr);
      final buf = StringBuffer();
      for (final t in doc.findAllElements('w:t')) {
        buf.write(t.innerText);
      }
      return buf.toString();
    }
    return '[Unsupported document: $ext]';
  }

  static Future<String?> _extractArchive(String path) async {
    final bytes = await File(path).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final buf = StringBuffer();
    int total = 0;
    for (final f in archive.files) {
      if (!f.isFile) continue;
      final name = f.name;
      final ext = p.extension(name.toLowerCase()).replaceFirst('.', '');
      if (!_codeExt.contains(ext) &&
          !['txt', 'md', 'json'].contains(ext)) {
        buf.writeln('=== $name (binary, skipped) ===');
        continue;
      }
      final Uint8List content =
          Uint8List.fromList(f.content as List<int>);
      final take = content.length > AppConstants.maxZipTextBytes
          ? content.sublist(0, AppConstants.maxZipTextBytes)
          : content;
      total += take.length;
      buf.writeln('=== FILE: $name ===');
      buf.writeln(utf8.decode(take, allowMalformed: true));
      buf.writeln();
      if (total > AppConstants.maxTotalExtractBytes) {
        buf.writeln('[…truncated: archive too large…]');
        break;
      }
    }
    return buf.toString();
  }
}
