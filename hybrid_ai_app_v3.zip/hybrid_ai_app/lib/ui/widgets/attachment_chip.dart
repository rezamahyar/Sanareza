import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../data/models/attachment.dart';

class AttachmentChip extends StatelessWidget {
  final Attachment attachment;
  final VoidCallback? onRemove;
  const AttachmentChip({
    super.key,
    required this.attachment,
    this.onRemove,
  });

  IconData get _icon => switch (attachment.type) {
        AttachmentType.image => Icons.image_outlined,
        AttachmentType.video => Icons.videocam_outlined,
        AttachmentType.archive => Icons.folder_zip_outlined,
        AttachmentType.document => Icons.description_outlined,
        AttachmentType.code => Icons.code,
        AttachmentType.unknown => Icons.insert_drive_file_outlined,
      };

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(_icon, size: 16),
      label: Text(
        attachment.name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 12),
      ),
      onDeleted: onRemove,
      deleteIcon: const Icon(Icons.close, size: 14),
    );
  }
}
