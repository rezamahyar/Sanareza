import 'package:flutter/material.dart';
import '../../services/token_service.dart';

class OffPeakBadge extends StatelessWidget {
  const OffPeakBadge({super.key});

  @override
  Widget build(BuildContext context) {
    final off = TokenService.isOffPeak();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: off
            ? Colors.green.withOpacity(.15)
            : Colors.orange.withOpacity(.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: off ? Colors.green : Colors.orange, width: .8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(off ? Icons.bolt : Icons.schedule,
              size: 12, color: off ? Colors.green : Colors.orange),
          const SizedBox(width: 4),
          Text(
            off ? 'تخفیف ۵۰٪ DeepSeek' : 'ساعت اوج',
            style: TextStyle(
              fontSize: 10,
              color: off ? Colors.green : Colors.orange,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
