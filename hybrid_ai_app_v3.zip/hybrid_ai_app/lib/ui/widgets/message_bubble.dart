import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:provider/provider.dart';
import '../../data/models/chat_message.dart';
import '../../providers/chat_provider.dart';
import '../../services/zip_builder.dart';
import '../../utils/code_detector.dart';
import '../screens/code_test_screen.dart';

class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const MessageBubble({super.key, required this.message});

  bool get isUser => message.role == MessageRole.user;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Align(
      alignment: isUser ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.9,
        ),
        decoration: BoxDecoration(
          color: isUser
              ? theme.colorScheme.primary.withOpacity(.12)
              : theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isUser ? 4 : 16),
            bottomRight: Radius.circular(isUser ? 16 : 4),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isUser && message.attachments.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Wrap(
                  spacing: 4,
                  children: message.attachments
                      .map((a) => Chip(
                            avatar:
                                const Icon(Icons.attach_file, size: 14),
                            label: Text(a.name,
                                style: const TextStyle(fontSize: 11)),
                            visualDensity: VisualDensity.compact,
                          ))
                      .toList(),
                ),
              ),
            _buildRichContent(context, message.content),
            if (!isUser && ZipBuilder.count(message.content) > 0)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  onPressed: () => _zipAll(context),
                  icon: const Icon(Icons.folder_zip_outlined, size: 18),
                  label: Text('دانلود ZIP (${ZipBuilder.count(message.content)} فایل)'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRichContent(BuildContext context, String text) {
    final fence = CodeDetector.fence;
    final parts = <Widget>[];
    int cursor = 0;
    for (final match in fence.allMatches(text)) {
      final before = text.substring(cursor, match.start).trim();
      if (before.isNotEmpty) {
        parts.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: SelectableText(before,
              style: const TextStyle(fontSize: 14, height: 1.6)),
        ));
      }
      final block = CodeDetector.fromMatch(match);
      parts.add(_codeCard(context, block));
      cursor = match.end;
    }
    if (cursor < text.length) {
      final rest = text.substring(cursor).trim();
      if (rest.isNotEmpty) {
        parts.add(SelectableText(rest,
            style: const TextStyle(fontSize: 14, height: 1.6)));
      }
    }
    if (parts.isEmpty) {
      return SelectableText(
        text.isEmpty ? '…' : text,
        style: const TextStyle(fontSize: 14, height: 1.6),
      );
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: parts);
  }

  Widget _codeCard(BuildContext context, CodeBlock b) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E26),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: const BoxDecoration(
              color: Color(0xFF2A2A38),
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    b.language.isEmpty ? 'code' : b.language,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'تست کد',
                  iconSize: 16,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(Icons.play_circle_outline,
                      color: Colors.greenAccent),
                  onPressed: () => _test(context, b),
                ),
                const SizedBox(width: 10),
                IconButton(
                  tooltip: 'کپی',
                  iconSize: 16,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(Icons.copy, color: Colors.white54),
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: b.code));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('کد کپی شد')),
                    );
                  },
                ),
                const SizedBox(width: 10),
                IconButton(
                  tooltip: 'ذخیره / اشتراک',
                  iconSize: 16,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(Icons.download, color: Colors.white54),
                  onPressed: () => _saveFile(context, b),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: HighlightView(
              b.code,
              language: CodeDetector.safeHighlightLanguage(b.language),
              theme: atomOneDarkTheme,
              padding: const EdgeInsets.all(12),
              textStyle: const TextStyle(
                  fontFamily: 'monospace', fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _zipAll(BuildContext context) async {
    try {
      final n = await ZipBuilder.buildAndShare(message.content);
      if (n == 0 && context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('کدی برای ZIP پیدا نشد')));
      }
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('خطا در ساخت ZIP: $e')));
    }
  }

  /// Opens the sandbox; if the user taps "send result to AI" the feedback is
  /// sent back to the chat so the model can fix its own code.
  Future<void> _test(BuildContext context, CodeBlock b) async {
    final chat = context.read<ChatProvider>();
    final feedback = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => CodeTestScreen(
          initialCode: b.code,
          initialLanguage: b.language,
        ),
      ),
    );
    if (feedback != null && feedback.trim().isNotEmpty) {
      await chat.send(userText: feedback, attachments: const []);
    }
  }

  Future<void> _saveFile(BuildContext context, CodeBlock b) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final ext = CodeDetector.extFor(b.language);
      final fname = b.named
          ? b.filename.split('/').last
          : 'snippet_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final file = File('${dir.path}/$fname');
      await file.writeAsString(b.code);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ذخیره شد: ${file.path}')),
      );
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('خطا: $e')));
    }
  }
}
