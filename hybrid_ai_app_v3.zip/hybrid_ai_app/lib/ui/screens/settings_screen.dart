import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/settings_provider.dart';
import 'tools_settings_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _geminiKey;
  late TextEditingController _deepseekKey;
  late TextEditingController _geminiModel;
  late TextEditingController _deepseekModel;
  bool _showGemini = false;
  bool _showDeepseek = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<SettingsProvider>();
    _geminiKey = TextEditingController(text: s.geminiKey);
    _deepseekKey = TextEditingController(text: s.deepseekKey);
    _geminiModel = TextEditingController(text: s.geminiModel);
    _deepseekModel = TextEditingController(text: s.deepseekModel);
  }

  @override
  void dispose() {
    _geminiKey.dispose();
    _deepseekKey.dispose();
    _geminiModel.dispose();
    _deepseekModel.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final s = context.read<SettingsProvider>();
    await s.setGeminiKey(_geminiKey.text);
    await s.setDeepseekKey(_deepseekKey.text);
    await s.setGeminiModel(_geminiModel.text);
    await s.setDeepseekModel(_deepseekModel.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تنظیمات ذخیره شد')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('🔑 کلیدهای API',
              style:
                  TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          _field(
            label: 'Gemini API Key',
            controller: _geminiKey,
            obscure: !_showGemini,
            onToggle: () => setState(() => _showGemini = !_showGemini),
          ),
          const SizedBox(height: 12),
          _field(
            label: 'DeepSeek API Key',
            controller: _deepseekKey,
            obscure: !_showDeepseek,
            onToggle: () =>
                setState(() => _showDeepseek = !_showDeepseek),
          ),
          const SizedBox(height: 24),
          const Text('🧠 مدل‌ها',
              style:
                  TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: _geminiModel,
            decoration: const InputDecoration(
              labelText: 'Gemini model',
              helperText: 'پیش‌فرض: gemini-2.0-flash',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _deepseekModel,
            decoration: const InputDecoration(
              labelText: 'DeepSeek model',
              helperText: 'پیش‌فرض: deepseek-v4-pro',
            ),
          ),
          const SizedBox(height: 24),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.tune),
            title: const Text('ابزارها و مصرف توکن'),
            subtitle: const Text('مدل ارزان، سندباکس تست کد'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => const ToolsSettingsScreen())),
          ),
          const SizedBox(height: 16),
          const Text('🎨 ظاهر',
              style:
                  TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.light, label: Text('روشن')),
              ButtonSegment(
                  value: ThemeMode.system, label: Text('سیستم')),
              ButtonSegment(value: ThemeMode.dark, label: Text('تیره')),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => s.setThemeMode(v.first),
          ),
          const SizedBox(height: 32),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('ذخیره تنظیمات'),
          ),
        ],
      ),
    );
  }

  Widget _field({
    required String label,
    required TextEditingController controller,
    required bool obscure,
    required VoidCallback onToggle,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        suffixIcon: IconButton(
          icon: Icon(obscure ? Icons.visibility : Icons.visibility_off),
          onPressed: onToggle,
        ),
      ),
    );
  }
}
