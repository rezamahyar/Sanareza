import 'package:flutter/material.dart';
import '../../core/extra_settings.dart';

class ToolsSettingsScreen extends StatefulWidget {
  const ToolsSettingsScreen({super.key});
  @override
  State<ToolsSettingsScreen> createState() => _ToolsSettingsScreenState();
}

class _ToolsSettingsScreenState extends State<ToolsSettingsScreen> {
  final _judge = TextEditingController();
  final _piston = TextEditingController();
  final _flash = TextEditingController();
  String _route = 'auto';
  String _sandbox = 'judge0';
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    ExtraSettings.load().then((_) {
      if (!mounted) return;
      setState(() {
        _route = ExtraSettings.routeMode;
        _sandbox = ExtraSettings.sandbox;
        _judge.text = ExtraSettings.judge0Url;
        _piston.text = ExtraSettings.pistonUrl;
        _flash.text = ExtraSettings.flashModel;
        _ready = true;
      });
    });
  }

  @override
  void dispose() {
    _judge.dispose();
    _piston.dispose();
    _flash.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    ExtraSettings.routeMode = _route;
    ExtraSettings.sandbox = _sandbox;
    ExtraSettings.judge0Url = _judge.text;
    ExtraSettings.pistonUrl = _piston.text;
    ExtraSettings.flashModel = _flash.text;
    await ExtraSettings.save();
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('ذخیره شد')));
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return Scaffold(
          appBar: AppBar(title: const Text('ابزارها و مصرف توکن')),
          body: const Center(child: CircularProgressIndicator()));
    }
    const h = TextStyle(fontWeight: FontWeight.bold, fontSize: 15);
    return Scaffold(
      appBar: AppBar(title: const Text('ابزارها و مصرف توکن')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('💸 انتخاب مدل', style: h),
          const SizedBox(height: 4),
          const Text(
              'خودکار: سؤال‌های کوتاه و ساده (بدون پیوست/کد) با مدل سریع و ارزان جواب داده می‌شوند؛ بقیه با مدل اصلی.',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'flash', label: Text('همیشه سریع')),
              ButtonSegment(value: 'auto', label: Text('خودکار')),
              ButtonSegment(value: 'pro', label: Text('همیشه اصلی')),
            ],
            selected: {_route},
            onSelectionChanged: (v) => setState(() => _route = v.first),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _flash,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              labelText: 'نام مدل سریع/ارزان',
              helperText: 'پیش‌فرض: deepseek-chat (خالی = همیشه مدل اصلی)',
            ),
          ),
          const SizedBox(height: 24),
          const Text('🧪 سندباکس تست کد', style: h),
          const SizedBox(height: 4),
          const Text(
              'Piston عمومی از ۲۰۲۶/۰۲/۱۵ بسته شده (خطای 401). پیش‌فرض اکنون Judge0 است. برای Dart یا زبان‌های دیگر، Piston شخصی وصل کنید.',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'judge0', label: Text('Judge0')),
              ButtonSegment(value: 'piston', label: Text('Piston شخصی')),
            ],
            selected: {_sandbox},
            onSelectionChanged: (v) => setState(() => _sandbox = v.first),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _judge,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(labelText: 'آدرس Judge0'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _piston,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              labelText: 'آدرس Piston شخصی',
              hintText: 'http://IP:2000/api/v2',
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('ذخیره'),
          ),
        ],
      ),
    );
  }
}
