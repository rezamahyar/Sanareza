import 'package:flutter/material.dart';
import '../../services/code_test_service.dart';
import 'live_preview_screen.dart';

class CodeTestScreen extends StatefulWidget {
  final String initialCode;
  final String initialLanguage;
  const CodeTestScreen({
    super.key,
    required this.initialCode,
    required this.initialLanguage,
  });

  @override
  State<CodeTestScreen> createState() => _CodeTestScreenState();
}

class _CodeTestScreenState extends State<CodeTestScreen> {
  late TextEditingController _codeCtrl;
  late TextEditingController _stdinCtrl;
  late String _language;

  bool _running = false;
  CodeTestResult? _result;
  String? _error;
  bool _showStdin = false;

  static const _languages = [
    'python', 'javascript', 'typescript', 'dart', 'java', 'kotlin',
    'swift', 'go', 'rust', 'c', 'cpp', 'csharp', 'php', 'ruby', 'bash',
    'html', 'css',
  ];

  @override
  void initState() {
    super.initState();
    _codeCtrl = TextEditingController(text: widget.initialCode);
    _stdinCtrl = TextEditingController();
    const aliases = {
      'py': 'python', 'js': 'javascript', 'ts': 'typescript',
      'kt': 'kotlin', 'rs': 'rust', 'c++': 'cpp', 'cs': 'csharp',
      'c#': 'csharp', 'rb': 'ruby', 'sh': 'bash', 'shell': 'bash',
      'htm': 'html',
    };
    var lang = widget.initialLanguage.toLowerCase();
    lang = aliases[lang] ?? lang;
    _language = _languages.contains(lang) ? lang : 'python';
  }

  @override
  void dispose() {
    _codeCtrl.dispose();
    _stdinCtrl.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    if (_running) return;
    setState(() {
      _running = true;
      _error = null;
      _result = null;
    });
    try {
      if (CodeTestService.isWebLanguage(_language)) {
        final html = HtmlPreviewBuilder.build(_codeCtrl.text, _language);
        if (!mounted) return;
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => LivePreviewScreen(
              html: html,
              title: 'پیش‌نمایش $_language',
            ),
          ),
        );
      } else {
        final result = await CodeTestService.run(
          code: _codeCtrl.text,
          language: _language,
          stdin: _stdinCtrl.text,
        );
        if (!mounted) return;
        setState(() => _result = result);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWeb = CodeTestService.isWebLanguage(_language);
    return Scaffold(
      appBar: AppBar(
        title: const Text('تست کد'),
        actions: [
          IconButton(
            tooltip: 'اجرا',
            icon: _running
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.play_arrow),
            onPressed: _running ? null : _run,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              const Text('زبان:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _language,
                  items: _languages
                      .map((l) => DropdownMenuItem(value: l, child: Text(l)))
                      .toList(),
                  onChanged: (v) => setState(() => _language = v ?? _language),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E26),
              borderRadius: BorderRadius.circular(10),
            ),
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _codeCtrl,
              maxLines: null,
              minLines: 12,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                color: Colors.white,
                height: 1.5,
              ),
              cursorColor: Colors.white,
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: '// کد خود را اینجا بنویسید…',
                hintStyle: TextStyle(color: Colors.white38),
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () => setState(() => _showStdin = !_showStdin),
            icon: Icon(_showStdin ? Icons.expand_less : Icons.expand_more),
            label: const Text('ورودی (stdin)'),
          ),
          if (_showStdin)
            TextField(
              controller: _stdinCtrl,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'ورودی برنامه را اینجا وارد کنید',
                labelText: 'stdin',
              ),
            ),
          const SizedBox(height: 12),
          if (isWeb)
            FilledButton.icon(
              onPressed: _running ? null : _run,
              icon: const Icon(Icons.visibility),
              label: const Text('پیش‌نمایش در WebView'),
            )
          else
            FilledButton.icon(
              onPressed: _running ? null : _run,
              icon: const Icon(Icons.play_arrow),
              label: const Text('اجرا در Sandbox'),
            ),
          const SizedBox(height: 20),
          if (_error != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(_error!,
                  style: const TextStyle(color: Colors.red, fontSize: 13)),
            ),
          if (_result != null) _resultView(),
          if (_result != null || _error != null)
            Padding(
              padding: const EdgeInsets.only(top: 14),
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).pop(_feedback()),
                icon: const Icon(Icons.auto_fix_high),
                label: const Text('ارسال نتیجه به هوش مصنوعی برای رفع خطا'),
              ),
            ),
        ],
      ),
    );
  }

  String _clip(String s) => s.length > 2000 ? '${s.substring(0, 2000)}…' : s;

  String _feedback() {
    final b = StringBuffer('این کد ($_language) را در سندباکس اجرا کردم.\n');
    if (_error != null) b.writeln('خطای اجرا: ${_clip(_error!)}');
    final r = _result;
    if (r != null) {
      b.writeln('exit code: ${r.exitCode}');
      if (r.compileStderr.isNotEmpty) b.writeln('compile error:\n${_clip(r.compileStderr)}');
      if (r.stderr.isNotEmpty) b.writeln('stderr:\n${_clip(r.stderr)}');
      if (r.stdout.isNotEmpty) b.writeln('stdout:\n${_clip(r.stdout)}');
    }
    b.writeln('\nکد اجراشده:\n```$_language\n${_codeCtrl.text}\n```');
    b.writeln('اگر مشکلی هست علت را بگو و کد کامل اصلاح‌شده بده؛ اگر درست است فقط تأیید کن.');
    return b.toString();
  }

  Widget _resultView() {
    final r = _result!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              r.success ? Icons.check_circle : Icons.error,
              color: r.success ? Colors.green : Colors.red,
              size: 18,
            ),
            const SizedBox(width: 6),
            Text(
              r.success ? 'اجرا موفق' : 'اجرا با خطا (کد ${r.exitCode})',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: r.success ? Colors.green : Colors.red,
              ),
            ),
            const Spacer(),
            Text('${r.elapsed.inMilliseconds} ms',
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
        const SizedBox(height: 8),
        if (r.compileStderr.isNotEmpty) _outputBox('خطای کامپایل', r.compileStderr, Colors.orange),
        if (r.stdout.isNotEmpty) _outputBox('خروجی (stdout)', r.stdout, Colors.green),
        if (r.stderr.isNotEmpty) _outputBox('خطا (stderr)', r.stderr, Colors.red),
        if (r.stdout.isEmpty && r.stderr.isEmpty && r.compileStderr.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('(خروجی خالی)', style: TextStyle(color: Colors.grey)),
          ),
      ],
    );
  }

  Widget _outputBox(String label, String content, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        border: Border.all(color: color.withOpacity(.4)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                  fontSize: 11)),
          const SizedBox(height: 6),
          SelectableText(
            content,
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 12,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
