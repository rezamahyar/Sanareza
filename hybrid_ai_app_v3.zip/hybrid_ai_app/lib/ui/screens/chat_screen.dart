import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../data/models/attachment.dart';
import '../../providers/chat_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/file_processor.dart';
import '../widgets/attachment_chip.dart';
import '../widgets/message_bubble.dart';
import '../widgets/off_peak_badge.dart';
import 'code_test_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<Attachment> _pending = [];
  final ImagePicker _picker = ImagePicker();

  @override
  void dispose() {
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final file = await _picker.pickImage(source: ImageSource.gallery);
    if (file == null) return;
    final bytes = await File(file.path).readAsBytes();
    setState(() {
      _pending.add(Attachment(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        name: file.name,
        path: file.path,
        sizeBytes: bytes.length,
        type: AttachmentType.image,
        mimeType: file.mimeType,
      ));
    });
  }

  Future<void> _pickVideo() async {
    final file = await _picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    final len = await File(file.path).length();
    setState(() {
      _pending.add(Attachment(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        name: file.name,
        path: file.path,
        sizeBytes: len,
        type: AttachmentType.video,
        mimeType: file.mimeType,
      ));
    });
  }

  Future<void> _pickFile() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;
    for (final f in res.files) {
      if (f.path == null) continue;
      setState(() {
        _pending.add(Attachment(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          name: f.name,
          path: f.path!,
          sizeBytes: f.size,
          type: FileProcessor.classify(f.name),
        ));
      });
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _textCtrl.text;
    if (text.trim().isEmpty && _pending.isEmpty) return;
    final chat = context.read<ChatProvider>();
    final attachments = List<Attachment>.from(_pending);
    _textCtrl.clear();
    setState(() => _pending.clear());
    _scrollToBottom();
    await chat.send(userText: text, attachments: attachments);
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final settings = context.watch<SettingsProvider>();

    if (chat.sending) _scrollToBottom();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: const [
            Text('Hybrid AI'),
            OffPeakBadge(),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.science_outlined),
            tooltip: 'تست کد',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const CodeTestScreen(
                  initialCode: 'print("Hello, World!")',
                  initialLanguage: 'python',
                ),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'گفتگوی جدید',
            onPressed: () => chat.newConversation(),
          ),
        ],
      ),
      body: Column(
        children: [
          if (!settings.ready)
            Container(
              width: double.infinity,
              color: Colors.orange.withOpacity(.15),
              padding: const EdgeInsets.all(12),
              child: const Text(
                '⚠️ برای شروع، کلیدهای Gemini و DeepSeek را در تنظیمات وارد کنید.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          if (chat.error != null)
            Container(
              width: double.infinity,
              color: Colors.red.withOpacity(.15),
              padding: const EdgeInsets.all(12),
              child: Text(chat.error!,
                  style: const TextStyle(fontSize: 12, color: Colors.red)),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Text('توکن: ${chat.tokensUsed}',
                    style:
                        const TextStyle(fontSize: 11, color: Colors.grey)),
                const SizedBox(width: 12),
                if (chat.costMultiplier < 1)
                  const Text('۵۰٪ تخفیف',
                      style: TextStyle(
                          fontSize: 11, color: Colors.green)),
              ],
            ),
          ),
          Expanded(
            child: chat.messages.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'یک فایل، عکس، ویدیو یا سوال خود را وارد کنید.\n'
                        'Gemini محتوا را تحلیل می‌کند و DeepSeek پاسخ نهایی را می‌نویسد.\n\n'
                        '🎯 روی هر بلوک کد در پاسخ، آیکن ▶ را بزنید تا اجرا شود.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: chat.messages.length,
                    itemBuilder: (_, i) =>
                        MessageBubble(message: chat.messages[i]),
                  ),
          ),
          if (_pending.isNotEmpty)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: _pending
                    .map((a) => Padding(
                          padding:
                              const EdgeInsetsDirectional.only(end: 6),
                          child: AttachmentChip(
                            attachment: a,
                            onRemove: () =>
                                setState(() => _pending.remove(a)),
                          ),
                        ))
                    .toList(),
              ),
            ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                border: Border(
                    top: BorderSide(
                        color: Theme.of(context).dividerColor,
                        width: .3)),
              ),
              child: Row(
                children: [
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.attach_file),
                    onSelected: (v) {
                      if (v == 'image') _pickImage();
                      if (v == 'video') _pickVideo();
                      if (v == 'file') _pickFile();
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                          value: 'image',
                          child: ListTile(
                              leading: Icon(Icons.image),
                              title: Text('تصویر'))),
                      PopupMenuItem(
                          value: 'video',
                          child: ListTile(
                              leading: Icon(Icons.videocam),
                              title: Text('ویدیو'))),
                      PopupMenuItem(
                          value: 'file',
                          child: ListTile(
                              leading: Icon(Icons.folder_zip),
                              title: Text('فایل / ZIP / سند'))),
                    ],
                  ),
                  Expanded(
                    child: TextField(
                      controller: _textCtrl,
                      minLines: 1,
                      maxLines: 5,
                      textInputAction: TextInputAction.newline,
                      decoration: const InputDecoration(
                        hintText: 'پیام یا سوال خود را بنویسید...',
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  chat.sending
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2.5),
                          ),
                        )
                      : IconButton.filled(
                          onPressed: _send,
                          icon: const Icon(Icons.send),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
