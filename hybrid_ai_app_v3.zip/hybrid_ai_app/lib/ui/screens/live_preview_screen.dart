import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LivePreviewScreen extends StatefulWidget {
  final String html;
  final String title;
  const LivePreviewScreen({
    super.key,
    required this.html,
    this.title = 'پیش‌نمایش زنده',
  });

  @override
  State<LivePreviewScreen> createState() => _LivePreviewScreenState();
}

class _LivePreviewScreenState extends State<LivePreviewScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..loadHtmlString(widget.html);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _controller.loadHtmlString(widget.html),
          ),
        ],
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}

/// Builds a self-contained HTML document for HTML/CSS/JS code.
class HtmlPreviewBuilder {
  static String build(String code, String language) {
    switch (language.toLowerCase()) {
      case 'html':
      case 'htm':
      case 'xml':
        if (!code.toLowerCase().contains('<html')) {
          return '<!DOCTYPE html><html><head>'
              '<meta charset="utf-8">'
              '<meta name="viewport" content="width=device-width,initial-scale=1">'
              '</head><body>$code</body></html>';
        }
        return code;
      case 'javascript':
      case 'js':
        return '<!DOCTYPE html><html><head>'
            '<meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<style>body{font-family:sans-serif;padding:8px;}'
            '#__console__{background:#111;color:#0f0;padding:8px;'
            'font-size:12px;white-space:pre-wrap;min-height:60px;'
            'border-radius:6px;font-family:monospace;}</style>'
            '</head><body>'
            '<pre id="__console__">Console:\n</pre>'
            '<script>'
            'const _c=document.getElementById("__console__");'
            'const _log=console.log.bind(console);'
            'console.log=(...a)=>{'
            '_log(...a);'
            '_c.textContent+=a.map(x=>typeof x==="object"?JSON.stringify(x):String(x)).join(" ")+"\\n";'
            '};'
            'console.error=(...a)=>console.log("ERROR:",...a);'
            'window.onerror=(m,s,l,c,e)=>{console.log("Uncaught:",m);};'
            '$code'
            '</script></body></html>';
      case 'css':
        return '<!DOCTYPE html><html><head>'
            '<meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<style>$code</style>'
            '</head><body>'
            '<div class="test">Preview sample text</div>'
            '<button>Button</button>'
            '<p>Paragraph text</p>'
            '<h1>Heading H1</h1>'
            '<a href="#">A link</a>'
            '</body></html>';
      default:
        return '<!DOCTYPE html><html><body>'
            '<pre style="white-space:pre-wrap;">$code</pre></body></html>';
    }
  }
}
