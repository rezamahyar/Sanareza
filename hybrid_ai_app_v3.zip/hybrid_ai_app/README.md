# Hybrid AI — APK Build Guide

## ✨ چه چیزی داخل این ریپو است
- اپ کامل Flutter با Gemini + DeepSeek + Code Sandbox
- workflow آماده برای ساخت APK در GitHub Actions

## 🚀 استقرار (۵ دقیقه)

### ۱. یک ریپوی خالی در GitHub بساز
نام پیشنهادی: `hybrid-ai-app` — Public یا Private (هر دو OK).

### ۲. فایل‌ها را آپلود کن
ساختار باید **دقیقاً** این باشد:

```
.github/workflows/build.yml
ci_assets/AndroidManifest.xml
lib/  (همه فایل‌های dart)
pubspec.yaml
analysis_options.yaml
README.md
```

⚠️ `android/` را آپلود نکن — workflow خودش می‌سازدش.

### ۳. Actions را فعال کن
Settings → Actions → General → Workflow permissions → **Read and write**

### ۴. اجرای Build
- یک commit push کن → build خودکار شروع می‌شود
- یا از تب Actions → Build Release APK → Run workflow

### ۵. دانلود APK
بعد از ~۵ دقیقه:
1. Actions → آخرین build
2. پایین صفحه → **Artifacts** → `hybrid-ai-app-apk-N`
3. APK را دانلود و نصب کن (Enable "Install unknown apps")

### ۶. داخل اپ
- Settings → کلیدهای Gemini و DeepSeek را وارد کن
- یک پیام بفرست یا فایل آپلود کن
- روی هر بلوک کد در پاسخ → دکمه ▶ (تست کد) را بزن
  - **HTML/CSS/JS** → پیش‌نمایش زنده در WebView (آفلاین)
  - **Python/JS/Dart/Java/C++/...** → اجرا در Judge0 (آنلاین، بدون کلید)؛ Dart فقط با Piston شخصی

## ⚠️ نکته‌های مهم
- `deepseek-v4-pro` نام رسمی نیست؛ اگر API خطا داد، در Settings به `deepseek-chat` یا `deepseek-reasoner` تغییر بده (بدون build مجدد).
- Piston عمومی بسته شده؛ سندباکس پیش‌فرض Judge0 است (Settings → ابزارها).
- برای تست کامل: VPN یا IP غیرایران توصیه می‌شود (Gemini/DeepSeek/Piston).
- اولین build ~۵ دقیقه، buildهای بعدی با cache ~۲ دقیقه.
