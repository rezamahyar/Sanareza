# V2 changes (what was done / what is untested)

## Done
1. Sandbox: public Piston is dead (401, whitelist since 2026-02-15). Default is now Judge0 CE
   (`https://ce.judge0.com`); self-hosted Piston URL optional (Settings → ابزارها و مصرف توکن).
2. Exact ZIP export: button under every assistant message with code. Uses the fence info string
   (```python src/app.py). Later block with same path replaces earlier. Also fixed the old fence
   regex that broke on "```python file.py".
3. Cheap model: ModelRouter (auto / always flash / always pro). Auto → flash for short plain questions.
4. Token savings: history 20→8 messages, old turns compacted (long code blocks cut), latest assistant
   message + current user message kept intact; system prompt asks for concise prose / changed files only.
5. Test loop: in the sandbox screen, "ارسال نتیجه به هوش مصنوعی" sends stdout/stderr + code back to chat.

## Install
- All patches are applied directly in the source. No extra workflow step is needed.

## NOT verified (no Flutter SDK was available when this was written)
- Never compiled: run the workflow and fix any analyzer error first.
- Judge0 language ids are from memory (python 71, js 63, ts 74, java 62, c 50, c++ 54, c# 51, go 60,
  rust 73, php 68, ruby 72, bash 46, kotlin 78, swift 83). Verify at <judge0 url>/languages.
- Dart can't run on Judge0 → needs own Piston.

## Ideas not started
- Fully automatic test→fix loop inside ChatProvider (max 3 rounds).
- Local JS runner through WebView (offline, no sandbox needed).
- Agent tools: let the model request "create_zip" / "run_code" as function calls.
